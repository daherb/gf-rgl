## README

This folder contains the texts annotated following the guidelines [v.2.0](https://github.com/PerseusDL/treebank_data/blob/master/AGDT2/guidelines/Greek_guidelines.md), created under the supervision of Giuseppe G. A. Celano. More information is contained in the subfolders.

