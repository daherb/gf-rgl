## README

This folder contains texts annotated according to the guidelines v.2 under the supervision of Giuseppe G. A. Celano. Here you can find the treebanked texts with full documentation concerning the annotation procedure:

* texts of two annotators 
* inter-coder agreement report
* adjudication file

The guidelines are in the treebank_data/AGDT2/guidelines folder. 
