Transformed versions of v1 treebank file for use in Arethusa (using 1.6 version of the treebank schema)
