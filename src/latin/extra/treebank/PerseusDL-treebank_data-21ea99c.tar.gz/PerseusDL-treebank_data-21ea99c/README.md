Treebank Data
=============

The repository contains the published Perseus Treebank Data. 

_The current release of the data is v. 2.0_ 

More information on the data is available within the folder for each version. 

The old website and old documentation are available here:
http://nlp.perseus.tufts.edu/syntax/treebank/greek.html

Copyright 2014 The Perseus Digital Library, Tufts University

Contents of this repository are licensed under a [Creative Commons Attribution-ShareAlike 3.0 United States License](http://creativecommons.org/licenses/by-sa/3.0/us/).

All materials in the AGLDT to which third-parties do not hold copyright are copyright of The Perseus Digital Library, Tufts University.
